# verkettete-liste-app
Projektarbeit Modul 411

## Angaben zum Code:
Max. Anz. Zeilen in Methode = 15

Alle Methoden / Funktionen sollen Kommentiert werden

Max. Zeilenbreite = 2/3 vom Bildschirm

Keine globalen Variablen

